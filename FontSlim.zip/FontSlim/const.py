source_path = "source"
target_path = "target"

nu_path = "3500NormalUse.txt"

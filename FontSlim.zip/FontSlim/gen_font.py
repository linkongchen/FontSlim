from slim import slim

slim()



